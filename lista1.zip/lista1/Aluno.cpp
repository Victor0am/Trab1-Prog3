#include "Aluno.h"
int Aluno::getcodigo(){
    return this->codigo;
}
void Aluno::setcodigo(int codigo){
    this->codigo = codigo;
}
string Aluno::getcpf(){
    return this->cpf;
}
void Aluno::setcpf(string cpf){
    this->cpf = cpf;
}
string Aluno::getrg(){
    return this->rg;
}
void Aluno::setrg(string rg){
    this->rg = rg;
}
string Aluno::getendereco(){
    return this->endereco;
}
void Aluno::setendereco(string endereco){
    this->endereco = endereco;
}
string Aluno::gettelefone(){
    return this->telefone;
}
void Aluno::settelefone(string telefone){
    this->telefone = telefone;
}
string Aluno::getemail(){
    return this->email;
}
void Aluno::setemail(string email){
    this->email = email;
}
string Aluno::getnome(){
    return this->nome;
}
void Aluno::setnome(string nome){
    this->nome = nome;
}