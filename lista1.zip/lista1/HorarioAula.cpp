#include "HorarioAula.h"

    string getdiaSemana(){
        return this->diaSemana;
    }
    void setdiaSemana(string diaSemana){
        this->diaSemana = diaSemana;
    }
    int getcodigo(){
        return this->codigo;
    }
    void setcodigo(int codigo){
        this->codigo = codigo;
    }