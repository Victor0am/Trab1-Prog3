#include "Matricula.h"
    int Matricula::getcodigo(){
        return this->codigo;
    }
    void Matricula::setcodigo(int codigo){
        this->codigo = codigo;
    }
    int Matricula::getnota(){
        return this->codigo;
    }
    void Matricula::setnota(int nota){
        this->nota = nota;
    }
    string Matricula::getsituacao(){
        return this->situacao;
    }
    void Matricula::setsituacao(string situacao){
        this->situacao = situacao;
    }