#include "Professor.h"

string Professor::getcpf(){
    return this->cpf;
}
string Professor::setcpf(string cpf){
    return this->cpf = cpf;
}
string Professor::getrg(){
    return this->rg;
}
string Professor::setrg(string rg){
    return this->rg = rg;
}
string Professor::getendereco(){
    return this->endereco;
}
string Professor::setendereco(string endereco){
    return this->endereco = endereco;
}
string Professor::gettelefone(){
    return this->telefone;
}
string Professor::settelefone(string telefone){
    return this->telefone = telefone;
}
string Professor::getemail(){
    return this->email;
}
string Professor::setemail(string email){
    return this->email = email;
}
string Professor::getnome(){
    return this->nome;
}
string Professor::setnome(string nome){
    return this->nome = nome;
}