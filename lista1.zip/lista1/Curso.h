#ifndef _CURSO_H
#define _CURSO_H

class Curso{
    private:
        int codigo;
        string nome;
    public:
        Sint getcodigo();
        void setcodigo(int codigo);
        string getnome();
        void setnome(string nome);
}

#endif