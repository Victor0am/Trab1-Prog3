#include "Serie.h"

    int Serie::getcodigo(){
        return this->codigo;
    }
    void Serie::setcodigo(int codigo){
        this->codigo = codigo;
    }
    string Serie::getnome(){
        return this->nome;
    }
    void Serie::setnome(string nome){
        this->nome = nome;
    }