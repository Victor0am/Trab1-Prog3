#ifndef _PROFESSOR_H
#define _PROFESSOR_H

class Professor {
    private:
        time_t DataAdmissao;
        time_t DataDemissao;
        string cpf;
        string rg;
        string endereco;
        string telefone;
        string email;
        string nome;
    public:
        static int qtdProfessores;
        string getcpf();
        void setcpf(string cpf);
        string getcrg();
        void getrg(string rg);
        string getendereco();
        void setendereco(string endereco);
        string gettelefone();
        void settelefone(string telefone);
        string getemail();
        void setemail(string email);
        string getnome();
        void setnome(string nome);


}

#endif