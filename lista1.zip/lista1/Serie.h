#ifndef _SERIE_H
#define _SERIE_H

class Serie{
    private:
        int codigo;
        string nome;
    public:
        Sint getcodigo();
        void setcodigo(int codigo);
        string getnome();
        void setnome(string nome);
}


#endif