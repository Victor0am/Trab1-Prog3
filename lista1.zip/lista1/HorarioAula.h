#ifndef _HORARIOAULA_H
#define _HORARIOAULA_H

class HorarioAula{
    private:
        string diaSemana;
        time_t HorarioFim;
        time_t HorarioInicio;
        int codigo;
    public:
        string getdiaSemana();
        void setdiaSemana(string diaSemana);
        int getcodigo();
        void setcodigo(int codigo);
}

#endif